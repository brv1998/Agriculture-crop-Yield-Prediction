

ALTER TABLE dbo.crops
ADD average_yield DECIMAL(10, 2);

SELECT * FROM information_schema.tables WHERE table_name = 'crops';

ALTER TABLE dbo.crops
ADD average_yield DECIMAL(10, 2);

USE VERTOCITY_DS_END_CAPSTONE2_PROJECT;


CREATE TABLE dbo.crops (
    crop_id INT PRIMARY KEY,
    crop_name VARCHAR(100),
    average_yield DECIMAL(10, 2) NULL
);

SELECT * FROM crops

CREATE PROCEDURE sp_update_average_yield
AS
BEGIN
    -- Update the average yield for each crop based on crop_yields table
    UPDATE dbo.crops
    SET average_yield = (
        SELECT AVG(yield)
        FROM dbo.crop_yields
        WHERE crop_yields.crop_id = dbo.crops.crop_id
    )
    FROM dbo.crops;
END;

-- Execute the stored procedure to update average yield
EXEC sp_update_average_yield;

SELECT * FROM dbo.crops;

ALTER TABLE dbo.crops
ADD average_yield DECIMAL(10, 2);

USE VERTOCITY_DS_END_CAPSTONE2_PROJECT;  -- Ensure to use the correct project
GO
EXEC sp_rename 'dbo.crops.aregion_id', 'region_id', 'COLUMN';


-- Crops Table Schema Example (assuming crop_id, crop_name, region_id columns exist)
CREATE TABLE dbo.crops (
    crop_id INT PRIMARY KEY,
    crop_name VARCHAR(100),
    region_id INT,
    average_yield DECIMAL(10, 2)
);



sp_help 'dbo.crops';

CREATE PROCEDURE sp_update_average_yield
AS
BEGIN
    UPDATE dbo.crops
    SET average_yield = (
        SELECT AVG(yield)
        FROM dbo.crop_yields
        WHERE crop_id = dbo.crops.crop_id
    );
END;

INSERT INTO dbo.crops (crop_id, crop_name, region_id, average_yield)
VALUES
(1, 'Rice', 1, NULL),
(2, 'Wheat', 2, NULL),
(3, 'Maize', 3, NULL);

CREATE PROCEDURE sp_update_average_yield
AS
BEGIN
    -- Update average yield in crops table based on crop_yields data
    UPDATE dbo.crops
    SET average_yield = (
        SELECT AVG(yield)
        FROM dbo.crop_yields
        WHERE crop_id = dbo.crops.crop_id
    );
END;

EXEC sp_update_average_yield;

SELECT * FROM dbo.crops;
