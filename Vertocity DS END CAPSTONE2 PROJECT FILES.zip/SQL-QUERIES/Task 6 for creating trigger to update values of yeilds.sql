

--crop_yield_history table creation
CREATE TABLE crop_yield_history (
    history_id INT PRIMARY KEY IDENTITY(1,1),
    crop_id INT,
    region_id INT,
    old_yield DECIMAL(10, 2),
    update_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

SELECT * FROM crop_yield_history

--crop_yields table
CREATE TABLE dbo.crop_yields (
    crop_id INT PRIMARY KEY,
    region_id INT,
    yield DECIMAL(10, 2)
);


--trigger 
CREATE TRIGGER trg_crop_yield_history
ON dbo.crop_yields
AFTER UPDATE
AS
BEGIN
    -- Insert the old values into crop_yield_history
    INSERT INTO dbo.crop_yield_history (crop_id, region_id, old_yield)
    SELECT crop_id, region_id, yield
    FROM deleted;
END;


-- Sample UPDATE operation
UPDATE dbo.crop_yields
SET yield = 2500
WHERE crop_id = 1;

Select * from crop_yields
-- Check the data in crop_yield_history
SELECT * FROM dbo.crop_yield_history;


USE VERTOCITY_DS_END_CAPSTONE2_PROJECT;


SELECT * FROM sys.triggers WHERE parent_id = OBJECT_ID('dbo.crop_yields');

SELECT * FROM dbo.crop_yield_history;

UPDATE dbo.crop_yields
SET yield = 2500
WHERE crop_id = 1;

SELECT * FROM dbo.crop_yields WHERE crop_id = 1;


INSERT INTO dbo.crop_yields (crop_id, region_id, yield)
VALUES (1, 101, 2000);  -- crop_id = 1, region_id = 101 ????? yield = 2000


