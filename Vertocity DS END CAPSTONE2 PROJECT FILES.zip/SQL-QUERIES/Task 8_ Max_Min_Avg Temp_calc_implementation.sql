SELECT 
    region_id, 
    MAX(temperature) AS max_temperature, 
    MIN(temperature) AS min_temperature, 
    AVG(temperature) AS avg_temperature
FROM 
    dbo.weather_data
GROUP BY 
    region_id;
